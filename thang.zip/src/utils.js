const calculateRem = (size) => (size / 16);

export default calculateRem;