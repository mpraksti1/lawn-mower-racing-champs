import React from 'react';
import { Route, Switch } from 'react-router-dom';
import AppHeader from '../../Components/AppHeader';
import Auth from '../Auth';
import Site from '../Site';
import styled from 'styled-components';
import 'whatwg-fetch';

const BaseStyles = styled.div`
  font-size: 100%;
  font-family: 'Gotham';
  background: #333;
`

const App = () => (
  <BaseStyles>
    <AppHeader />
    <main>
      <Switch>
        <Route path="/auth" component={Auth} />
        <Route path="/" component={Site} />
      </Switch>
    </main>
  </BaseStyles>
);

export default App;
