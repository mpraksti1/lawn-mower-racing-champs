import React from 'react';
import { Route, Switch, withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import Home from '../../Pages/Home';
import Roster from '../../Pages/Roster';
import Player from '../../Pages/Player';
import styled from 'styled-components';
import { logout } from '../../Store/Actions/Auth';
import { createPlayer, deletePlayer, retrievePlayers } from '../../Store/Actions/Player';

const StyledDiv = styled.div`
  padding: 0 ${({theme}) => theme.baseSizeUnit * 2}px ${({theme}) => theme.baseSizeUnit * 2}px;
`

const Site = props => {
  // Redirect away from all non-auth routes if not logged in
  console.log(window.localStorage.token);
  console.log(window.localStorage.expiresIn);
  console.log(Date.now());

  const logoutAndRedirect = path => {
    props.logUserOut();
    props.history.push(path);
  }

  if (!window.localStorage.token) {
    logoutAndRedirect('/auth/register');
  } else if (window.localStorage.token && window.localStorage.expiresIn < Date.now()) {
    logoutAndRedirect('/auth/login');
  }

  const { 
    createPlayerFunc,
    retrievePlayersFunc,
    deletePlayerFunc,
  } = props;

  return (
    <StyledDiv>
      <Switch>
        <Route 
          path="/roster" 
          render={(props) => (
            <Roster 
              {...props} 
              retrievePlayers={retrievePlayersFunc} 
              deletePlayer={deletePlayerFunc}
            />
          )}
        />
        <Route 
          path="/player/new" 
          render={(props) => <Player {...props} createPlayer={createPlayerFunc} />}
        />
        <Route path="/" component={Home} />
      </Switch>
    </StyledDiv>
  );
};

const mapDispatchToProps = ({
  logUserOut: logout,
  createPlayerFunc: createPlayer,
  deletePlayerFunc: deletePlayer,
  retrievePlayersFunc: retrievePlayers,
})

export default withRouter(connect(null, mapDispatchToProps)(Site));
