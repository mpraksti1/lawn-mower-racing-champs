import React from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import BGVideo from '../../Components/BGVideo';
import FormModal from '../../Components/FormModal';
import {
  login,
  register,
} from '../../Store/Actions/Auth';

const Auth = ({registerFunc, loginFunc}) => (
  <div>
    <BGVideo url="/assets/video/bgvid.mp4" dark />
    <FormModal register={registerFunc} login={loginFunc}/>
  </div>
);

Auth.propTypes = {
  loginFunc: PropTypes.func.isRequired,
  registerFunc: PropTypes.func.isRequired,
};

const mapDispatchToProps = {
  loginFunc: login,
  registerFunc: register,
};

export default connect(null, mapDispatchToProps)(Auth);


