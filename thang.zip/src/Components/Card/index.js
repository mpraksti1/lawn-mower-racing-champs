import React from 'react'
import styled from 'styled-components';
import Text from '../../Elements/Text';

const StyledDiv = styled.div`
  .icon {
    text-align: center;
    
    svg {
      fill: white;
      height: 60px;
      width: 60px;
    }
  }
`

const Card = ({children, title, copy}) => {
  return (
    <StyledDiv>
      <div className="icon">{children}</div>
      <Text sans block alignCenter xlg spaceAround>{title}</Text>
      <Text sans block alignCenter thin spaceAround>{copy}</Text>
    </StyledDiv>
  )
}

export default Card;