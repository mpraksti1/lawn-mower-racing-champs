import React, { Component } from 'react';
import { Route, Switch, NavLink, withRouter } from 'react-router-dom';
import Loader from '../../Elements/Loader';
import LoginForm from '../../Forms/Login';
import RegisterForm from '../../Forms/Register';
import PlayerForm from '../../Forms/Player';
import LockIcon from 'react-icons/lib/md/lock';
import CreateIcon from 'react-icons/lib/md/create';
import StyledDiv from './styles';

class FormModal extends Component {
  constructor(props) {
    super(props);

    this.state = { isRequesting: false };

    this.fakeLoadingTime = this.fakeLoadingTime.bind(this);
    this.renderTabs = this.renderTabs.bind(this);
  }

  fakeLoadingTime() {
    console.log('start');
    this.setState({ isRequesting: true});
    setTimeout(() => {
      console.log('end');
      this.setState({ isRequesting: false});
    }, 5000);
  }

  renderTabs() {
    if(this.props.location.pathname !== '/player/new' && !this.state.isRequesting) {
      return (
        <div className="tab-wrapper">
          <NavLink to="/auth/register" className="tab-link area-left">
            <LockIcon />
            <span className="text-small">Register</span>
          </NavLink>
          <NavLink to="/auth/login" className="tab-link area-right">
            <CreateIcon />  
            <span className="text-small">Login</span>
          </NavLink>
        </div>
      );
    }
  }

  render() {
    const { login, register, createPlayer } = this.props;

    return (
      <StyledDiv>
        {this.renderTabs()} 
        { 
          this.state.isRequesting 
          ? <Loader />     
          : <div className="forms-area">
              <Switch>
                <Route 
                  path="/auth/login" 
                  render={(props) => (
                    <LoginForm
                      {...props}
                      login={login}
                      loader={this.fakeLoadingTime}
                    />
                  )}
                />
                <Route 
                  path="/auth/register" 
                  render={(props) => (
                    <RegisterForm
                      {...props}
                      register={register}
                      loader={this.fakeLoadingTime}
                    />
                  )}
                />
                <Route 
                  path="/player/new" 
                  render={(props) => (
                    <PlayerForm
                      {...props}
                      createPlayer={createPlayer}
                      loader={this.fakeLoadingTime}
                    />
                  )}
                />
              </Switch>
            </div>
        }
      </StyledDiv>
    );
  }
};

export default withRouter(FormModal);
