import React, { Component } from 'react';
import PropTypes from 'prop-types';
import DeleteIcon from 'react-icons/lib/md/clear';
import Text from '../../Elements/Text'
import StyledTable from './styles';

class PlayerList extends Component {
  constructor(props) {
    super(props)

    this.state = { players: [] };
    this.token = window.localStorage.token;
    this.retrievePlayers = this.retrievePlayers.bind(this);
    this.renderHeaderRow = this.renderHeaderRow.bind(this);
    this.renderRows = this.renderRows.bind(this);
  }

  componentDidMount() {
    this.retrievePlayers();
  }
  
  updateList = data => this.setState({ players: data.players});

  rng() {
    return Math.ceil(Math.random() * 50);
  };

  async retrievePlayers() {    
    try {
      const data = await this.props.retrievePlayers(this.token);
      this.updateList(data);
    } catch(e) {
      console.log(e);
    }
  }
  
  async deleteThisPlayer(id) {
    try {
      await this.props.deletePlayer(id, this.token);
      this.retrievePlayers();
    } catch(e) {
      console.log(e);
    }
  }

  generateRandomProfilePic() {
    const rngMW = this.rng() < 25 ? 'men' : 'women';
    const randomUser = this.rng();
    return `https://randomuser.me/api/portraits/${rngMW}/${randomUser}.jpg`
  }

  renderHeaderRow() {
    const { headerNames } = this.props;
    const headerRowColumns = headerNames.map((colName, idx) => {
      const replacedUnderscore = colName.replace(/_/g, " ");
      
      return (
        <th key={idx}>{ replacedUnderscore }</th>
      )
    });
    return (
      <tr>
        <th>Profile Img</th>
        {headerRowColumns}
        <th></th>
      </tr>
    );
  };

  renderRows() {
    const { headerNames } = this.props;
    const { players } = this.state;
    console.log(players);
    if (players.length) {
      return players.map((player, idx) => {
  
        const columns = headerNames.map((columnName, idx) => {
          const playerTrait = player[columnName];
          const label = columnName.replace(/_/g, " ");
          
          console.log({ columnName, playerTrait });
  
          return <td key={idx} data-label={label}>{playerTrait}</td>
        });
  
        return (
          <tr key={idx}>
            <td className="profile-pic">
              <img 
                src={this.generateRandomProfilePic()} 
                alt="icon"/>
            </td>
            {columns}
            <td className="delete-player" onClick={() => this.deleteThisPlayer(player.id)}><DeleteIcon /></td>
          </tr>
        );
      })
    } else {
      return (
        <tr>
          <td colSpan="6">
            <Text 
              xlg thin sans 
              spaceAround alignCenter
              gray block>Uh oh... you haven't added any racers yet.</Text>
          </td>
        </tr>
      )
    }
  };

  render() {
    return (
      <StyledTable className="responsive-table">
        <thead>
          {this.renderHeaderRow()}
        </thead>
        <tbody>
          {this.renderRows()}
        </tbody>
      </StyledTable>
    );
  }
};

PlayerList.propTypes = {
  headerNames: PropTypes.arrayOf(PropTypes.string).isRequired,
};

export default PlayerList;
