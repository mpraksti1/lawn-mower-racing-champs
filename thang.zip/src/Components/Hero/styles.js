import styled from 'styled-components';

const StyledDiv = styled.div`
  height: 500px;
  position: relative;
  margin: 0 -${({theme}) => theme.baseSizeUnit * 2}px;
  background-color: ${({theme}) => theme.darGrey};
  background-image: url( ${({imgUrl}) => imgUrl} );
  background-size: cover;
`
export default StyledDiv;