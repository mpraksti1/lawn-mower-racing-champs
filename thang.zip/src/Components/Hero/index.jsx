import React from 'react'
import Centered from '../../Elements/Centered';
import StyledDiv from './styles';

export default props => {
  const { imgUrl, children } = props;

  return (
    <StyledDiv imgUrl={imgUrl}>
      <Centered>
        { children }
      </Centered>
    </StyledDiv>
  );
}
