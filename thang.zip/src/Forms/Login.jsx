import React from 'react';
import EmailIcon from 'react-icons/lib/md/email';
import EyeIcon from 'react-icons/lib/md/remove-red-eye';
import BaseForm from './BaseForm';
import Button from '../Elements/Button';
import Text from '../Elements/Text'
import { Formik, Field, Form } from 'formik';

const LoginForm = props => (
  <BaseForm>
    <Formik
      initialValues={{
        email: '',
        password: '',
      }}
      onSubmit={async creds => {
        console.log(props);
        try {
          props.login(creds);
          props.loader();
          setTimeout(() => {
            props.history.push('/roster');
          }, 5000);
        } catch(e) {
          console.log(e);
        }
      }}
      component={MyForm}
    />
  </BaseForm>
);

const MyForm = () => (
  <div>
    <Text xlg sans spaceAbove block>Welcome back!</Text>
    <Text sm thin spaceBelow block>Good to see you again!</Text>
    <Form>
      <div className="icon-input">
        <EmailIcon />
        <Field type="email" name="email" placeholder="E-mail" />
      </div>
      <div className="icon-input">
        <EyeIcon />
        <Field type="password" name="password" placeholder="Password" />
      </div>
      <Button outline type="submit">Submit</Button>
    </Form>
  </div>
);

export default LoginForm;
