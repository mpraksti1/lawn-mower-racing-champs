import React from 'react';
import PersonIcon from 'react-icons/lib/md/person';
import StarIcon from 'react-icons/lib/md/star';
import HandIcon from 'react-icons/lib/md/pan-tool';
import BaseForm from './BaseForm';
import Button from '../Elements/Button';
import Text from '../Elements/Text'
import { Formik, Field, Form } from 'formik';

const PlayerForm = props => (
  <BaseForm>
    <Formik
      initialValues={{
        first_name: '',
        last_name: '',
        rating: '1',
        handedness: 'right',
      }}
      onSubmit={async player => {
        console.log(props);
        const token = window.localStorage.token;
        try {
          props.createPlayer(player, token);
          props.loader();
          setTimeout(() => {
            props.history.push('/roster');
          }, 5000);
        } catch(e) {
          console.log(e);
        }
      }}
      component={MyForm}
    />
  </BaseForm>
);

const MyForm = () => (
  <div>
    <Text xlg thin sans spaceAround block>Add a racer:</Text>
    <Form>
      <div className="icon-input">
        <PersonIcon />
        <Field type="text" name="first_name" placeholder="Fist Name" />
      </div>
      <div className="icon-input">
        <PersonIcon />
        <Field type="text" name="last_name" placeholder="Last Name" />
      </div>
      <div className="icon-input">
        <StarIcon />
        <Field component="select" name="rating">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
        </Field>
      </div>
      <div className="icon-input">
        <HandIcon />
        <Field component="select" name="handedness">
          <option value="right">Right</option>
          <option value="left">Left</option>
        </Field>
      </div>
      <Button outline type="submit">Submit</Button>
    </Form>
  </div>
);

export default PlayerForm;
