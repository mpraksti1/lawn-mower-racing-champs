import React from 'react';
import PersonIcon from 'react-icons/lib/md/person';
import EmailIcon from 'react-icons/lib/md/email';
import EyeIcon from 'react-icons/lib/md/remove-red-eye';
import BaseForm from './BaseForm';
import Button from '../Elements/Button';
import Text from '../Elements/Text';
import { Formik, Field, Form } from 'formik';

const RegistrationForm = props => (
  <BaseForm>
    <Formik
      initialValues={{
        first_name: '',
        last_name: '',
        email: '',
        password: '',
        confirm_password: '',
      }}
      onSubmit={async user => {
        console.log(props);
        try {
          props.register(user);
          props.loader();
          setTimeout(() => {
            props.history.push('/');
          }, 5000);
        } catch(e) {
          console.log(e);
        }
      }}
      component={MyForm}
    />
  </BaseForm>
);

const MyForm = () => (
  <div>
    <Text xlg sans spaceAbove block>Welcome to the LMRC</Text>
    <Text sm thin spaceBelow block>Fill in the form below for access to a personalized roster of your favorite RCLM athletes!</Text>
    <Form>
      <div className="icon-input">
        <PersonIcon />  
        <Field type="text" name="first_name" placeholder="First Name" />
      </div>
      <div className="icon-input">
        <PersonIcon />
        <Field type="text" name="last_name" placeholder="Last Name" />
      </div>
      <div className="icon-input">
        <EmailIcon />
        <Field type="email" name="email" placeholder="E-mail" />
      </div>
      <div className="icon-input">
        <EyeIcon />
        <Field type="password" name="password" placeholder="Password" />
      </div>
      <div className="icon-input">
        <EyeIcon />
        <Field type="password" name="confirm_password" placeholder="Confirm Password" />
      </div>
      <Button outline type="submit">Submit</Button>
    </Form>
  </div>
);

export default RegistrationForm;
