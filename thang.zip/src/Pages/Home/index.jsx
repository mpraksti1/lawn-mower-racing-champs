
import React from 'react';
import Text from '../../Elements/Text';
import Hero from '../../Components/Hero';
import EmailIcon from 'react-icons/lib/md/email';
import Card from '../../Components/Card';
import styled from 'styled-components';

const StyledDiv = styled.div`
  display: grid;
  grid-column-gap: 16px;
  grid-row-gap: 16px;
  margin-top: 16px;

  @media screen and (min-width: 768px) {
    grid-template-columns: 1fr 1fr 1fr;
  }

  div {
    background: #1f1f1f;
    padding: 16px;
    border-radius: 2px;
  }
`

const Home = () => (
  <div>
    <Hero imgUrl="./assets/images/homebg.jpg">
      <Text sans xxlg spaceBelow block>Welcome to the Lawn Mowing Racing Championships!</Text>
      <Text sans thin lg block>Add and remove racers from the roster at will, their fate is in your hands.</Text>
    </Hero>
    <StyledDiv>
      <Card title="Fast" copy="The fastest lawn mowers this side of the river!">
        <EmailIcon />
      </Card>
      <Card title="Fast" copy="The fastest lawn mowers this side of the river!">
        <EmailIcon />
      </Card>
      <Card title="Fast" copy="The fastest lawn mowers this side of the river!">
        <EmailIcon />
      </Card>
    </StyledDiv>
  </div>
);

export default Home;
