import React from 'react';
import BGVideo from '../../Components/BGVideo';
import FormModal from '../../Components/FormModal';

const Player = props => {
  console.log('Player Page', props);
  return (
    <div className="player-page">
      <BGVideo dark url="/assets/video/bgvid.mp4" />
      <FormModal createPlayer={props.createPlayer}/>
    </div>
  )
};

export default Player;
