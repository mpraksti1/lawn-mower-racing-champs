import React from 'react';
import { Link } from 'react-router-dom';
import PlayerList from '../../Components/PlayerList';
import Button from '../../Elements/Button';
import Text from '../../Elements/Text';

const headerNames = ['first_name', 'last_name', 'rating', 'handedness'];

const Roster = props => (
  <div className="roster-page">
    <Text xlg sans block spaceAbove>Your LMRC Roster:</Text>
    <Text sm thin spaceBelow block>Below are the players you've picked so far</Text>
    {console.log('IN ROSTER', props)}
    <PlayerList 
      headerNames={headerNames} 
      retrievePlayers={props.retrievePlayers}
      deletePlayer={props.deletePlayer}
    />
    <Button outline spaceAbove>
      <Link to="/player/new">
        <Text sm green>Add New</Text>
      </Link>
    </Button>
  </div>
);

export default Roster;
