import {
  CREATE_PLAYER,
  DELETE_PLAYER,
  RETRIEVE_PLAYERS,
} from '../Actions/Types';

const initialState = {};

export default (state = initialState, action) => {
  switch (action.type) {
    case CREATE_PLAYER:
      return {
        ...state
      }

    case DELETE_PLAYER:
      return {
        ...state,
      }

    case RETRIEVE_PLAYERS:
      return {
        ...state,

      }

    default:
      return state
  }
}

