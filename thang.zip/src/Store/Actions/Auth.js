import {
  ASYNC_REQUESTED,
  REGISTER,
  LOGIN,
  LOGOUT,
} from './Types';

const api = 'https://players-api.developer.alchemy.codes/api';

async function registerRequest (user) {
  const data = JSON.stringify(user);

  const response = await fetch(`${api}/user`, {
    headers: {
      'Content-type': 'application/json',
    },
    method: 'POST',
    body: data,
  });
  
  return response.json();
}

export const register = (user) => {
  return async dispatch => {
    dispatch({
      type: ASYNC_REQUESTED,
    });
    try {
      const data = await registerRequest(user);
      console.log('data', data);
      window.localStorage.setItem('token', data.token);
      window.localStorage.setItem('expiresIn', `${(60 * 60 * 1000) + Date.now()}`);
      dispatch({
        type: REGISTER,
        payload: data,
      });
    } catch (e) {
      console.log(e);
    }
  };
};


async function loginRequest (creds) {
  const data = JSON.stringify(creds);

  const response = await fetch(`${api}/login`, {
    headers: {
      'Content-type': 'application/json',
    },
    method: 'POST',
    body: data,
  });
  
  return response.json();
}

export const login = (creds) => {
  return async dispatch => {
    dispatch({
      type: ASYNC_REQUESTED,
    });

    try {
      const data = await loginRequest(creds);
      console.log('data', data);
      window.localStorage.setItem('token', data.token);
      window.localStorage.setItem('expiresIn', `${(60 * 60 * 1000) + Date.now()}`);
      dispatch({
        type: LOGIN,
      });
      console.log(data);
    } catch (e) {
      console.log(e);
    }
  };
};

export const logout = () => {
  return async dispatch => {
    window.localStorage.removeItem('token');
    window.localStorage.removeItem('expiresIn');
    dispatch({
      type: LOGOUT,
    });
  };
};
