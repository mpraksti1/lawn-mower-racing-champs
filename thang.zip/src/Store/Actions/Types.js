export const ASYNC_REQUESTED = 'async/ASYNC_REQUESTED'
export const REGISTER = 'auth/REGISTER'
export const LOGIN = 'auth/LOGIN'
export const LOGOUT = 'auth/LOGOUT'
export const CREATE_PLAYER = 'player/CREATE_PLAYER'
export const DELETE_PLAYER = 'player/DELETE_PLAYERS'
export const RETRIEVE_PLAYERS = 'player/RETRIEVE_PLAYERS'



