import {
  CREATE_PLAYER,
  DELETE_PLAYER,
  RETRIEVE_PLAYERS,
} from './Types';

const api = 'https://players-api.developer.alchemy.codes/api';

async function retrievePlayersRequest (token) {
  const response = await fetch(`${api}/players`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  
  return response.json();
};

export const retrievePlayers = (player) => {
  return async dispatch => {
    try {
      const data = await retrievePlayersRequest(player);
      
      console.log('data', data);
      dispatch({
        type: RETRIEVE_PLAYERS,
        payload: data,
      });
      return data;
    } catch (e) {
      console.log(e);
    }
  };
};


async function createPlayerRequest (player, token) {
  const data = JSON.stringify(player);

  const response = await fetch(`${api}/players`, {
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    method: 'POST',
    body: data,
  });
  
  return response.json();
}

export const createPlayer = (player, token) => {
  return async dispatch => {
    try {
      const data = await createPlayerRequest(player, token);
      console.log('data', data);
      dispatch({
        type: CREATE_PLAYER,
      });
    } catch (e) {
      console.log(e);
    }
  };
};


async function deletePlayerRequest (id, token) {
  const response = await fetch(`${api}/players/${id}`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
    method: 'DELETE',
  });
  
  return response.json();
}

export const deletePlayer = (id, token) => {
  return async dispatch => {
    try {
      const data = await deletePlayerRequest(id, token);
      console.log('data', data);
      dispatch({
        type: DELETE_PLAYER,
      });
    } catch (e) {
      console.log(e);
    }
  };
};
